# GROUP MEMBERS
# MARC STORM LARSEN, mlarsen
# SEBASTIAN PITUSCAN, pituscan

$port = nil
$hostname = nil

$nodeLock = Mutex.new

require 'socket'
require_relative 'node_class'
require_relative 'priority_queue'

# This method is made into a block comment as it isn't strictly necessary for Part 0.

=begin
def createHeader(srcIP, destIP, srcName, fragment_flag, fragOffset, lengthOfData, ttl, routingType, msgType)
	return [srcIP, destIP, srcName, fragment_flag.to_s, fragOffset.to_s, lengthOfData.to_s, ttl.to_s, routingType, msgType, $headerLength.to_s].join(',')
end
=end

=begin
1. Discover its neighbors and learn their network addresses. Check
2. Set the distance or cost metric to each of its neighbors. Check
3. Construct a packet telling all it has just learned. Check
4. Send this packet to and receive packets from all other routers.
5. Compute the shortest path to every other router.
=end
def createLinkStatePacket()
	# Construct the packet.
	# Packet should contain following information:
	# - "FLOODING"
	# - Source node name
	# - Sequence number
	# - Neighbor node name and link cost to the node.
	packet = ["FLOODING", $hostname, $sequenceNumber].join(',')
	$name_to_node.each_value { |n|
		if n.isNeighbor
			packet = [packet, n.name, n.linkCost].join(',')
		end
	}

	# The sequence number has been used for a packet and therefore needs to be incremented for the next packet.
	$sequenceNumber += 1

	return packet
end

def storeLinkStatePacket(packet)
	src = packet[0]
	destAndLinkCost = packet[2..-1] # Every destination is followed by the link cost from src to dest.

	# Check if the inner hash has been initialised before.
	if !$edges.has_key?(src)
		$edges[src] = Hash.new
	end

	# Store destination and link cost information
	(0..destAndLinkCost.length-1).step(2) do |i|
		nodeName = destAndLinkCost[i]
		cost = Integer(destAndLinkCost[i+1])

		# We need to store information from the link state packet sent out by the node itself.
		$edges[src][nodeName] = cost
	end
	return
end

def flooding(packet)

	src = packet[0]
	seq = Integer(packet[1])

	# Check if the packet is a duplicate or old.
	if !$src_to_seq.has_key?(src) || seq > $src_to_seq[src]
		$src_to_seq[src] = seq
	else
		return
	end


	storeLinkStatePacket(packet)

	# Flood to neighbors.
	# This for each might not need the first condition of the if statement.
	$socket_to_node.each { |socket, node|
		if node.isNeighbor && node.name != src # Send the packet to neighbors expect from the one you received it from.
			socket.puts(packet)
		end
	}
end

def updateNodeObject(v)
	if $name_to_node.has_key?(v) # Check if the node object exists.
		node = $name_to_node[v]
		node.distance = $distances[v]
	else # If it doesn't exists, create a node object and add it to data structure.
		# NOT SURE IF THIS IS CORRECT.
		node = NodeClass.new
		node.socket = nil
		node.name = v
		node.ipAddress = nil
		node.port = $nodes[v]
		node.distance = $distances[v]
		node.nextHop = nil
		node.isNeighbor = false
		node.linkCost = nil
		$name_to_node[v] = node
	end

end

def findNextHop()
	$edges.each_key { |k|
		next if k == $hostname # If k is equal to the $hostname there will be no nextHop to update in the 3 hash.

		predecessor = $predecessor[k]
		currentNextHop
		while predecessor != $hostname
			currentNextHop = predecessor
			predecessor = $predecessor[nodeName]
		end

		node = $name_to_node[k]
		node.nextHop = currentNextHop
	}
end

# Add every node from the $edges hash to the priority queue with value infinity except
# from src which has value 0.
def addToPriorityQueue()
	$edges.keys.each { |key|
		if key == $hostname
			$priorityQueue.insert(key, 0)
			$predecessor[key] = nil
			$distances[key] = 0
		else
			# Largest 32 bit number + 1. Assumed that all costs are represented by 32 bit integer.
			$priorityQueue.insert(key, 4611686018427387903)
			$predecessor[key] = nil
			$distances[key] = 4611686018427387903
		end
	}
end

# Method will return the link cost between u and v.
def weight(u, v)
	return $edges[u][v]
end

# Method will relax two nodes, determining if the distance to a node should be updated.
def relax(u, v)
	if $distances[v] > $distances[u] + weight(u,v)
		$distances[v] = $distances[u] + weight(u,v)
		updateNodeObject(v) # Update the node object in 3 hash with the new distance from $hostname to v.
		$priorityQueue.changeKey(v, $distances[v])
		$predecessor[v] = u
	end
end

def dijkstra()
	$priorityQueue = PriorityQueue.new
	$predecessor = Hash.new
	$distances = Hash.new
	addToPriorityQueue()

	while !$priorityQueue.isEmpty
		u = $priorityQueue.extractMin
		$edges[u].keys.each { |v|
			relax(u, v)
		}
	end

	findNextHop()
end

# Method that will add a node object to the three hashes.
# NOTE: this method can only be used when both socket, name and IP address of the node is known.
def addNode(node, socket, name, ipAddress)
	$socket_to_node[socket] = node
	$ip_to_node[ipAddress] = node
	$name_to_node[name] = node
end

# --------------------- Part 0 --------------------- #
# Method to build an edge (connection) between two nodes in the network.
# This method is used when the EDGEB command is received from STDin.
def edgeb(args)
	srcIP = args[0]
	destIP = args[1]
	dest = args[2]
	destPort = $nodes[dest] # Get the port associated with the name.

	socket = TCPSocket.new(destIP, destPort)

	# Create the node object and add additional information.
	node = NodeClass.new
	node.socket = socket
	node.name = dest
	node.ipAddress = destIP
	node.port = destPort
	node.distance = 1
	node.nextHop = dest
	node.isNeighbor = true
	node.linkCost = 1

	addNode(node, socket, dest, destIP) # Add the node object to the three hashes.

	# Send message to the node to build an edge (connection) with.
	# Message contains the necessary information in order for the receiving node to create a node object.
	socket.puts(["EDGEB", srcIP, $hostname].join(','))
end

# Method to build an edge (connection) between two nodes in the network.
# This method is used when the EDGEB command is received from another node in the network.
def edgeb_network(args, socket)
	STDOUT.puts "EDGEB network entered."
	destIP = args[0] # destIP is the IP address of the node who send the message.
	dest = args[1] # dest is the name of the node who send the message.
	destPort = $nodes[dest] # Get the port associated with the name.

	node = $socket_to_node[socket]
	node.name = dest
	node.ipAddress = destIP
	node.port = destPort
	node.distance = 1
	node.nextHop = dest
	node.isNeighbor = true
	node.linkCost = 1

	# Add the node to the two remaining hashes. When the node object was created it was added to socket_to_node.
	$ip_to_node[destIP] = node
	$name_to_node[dest] = node

	return
end

# Method that will write to node's current view of the routing table to a file.
def dumptable(args)
	filename = args[0]

	if !File.exists?(filename) then # If the file doesn't exists, create a new file.
		f = File.new(filename, "w")
	else # else if the file exists, open it and overwrite existing content.
		# "w" denotes that you can only write to the file and the existing content of the file will be overwritten.
		f = File.open(filename, "w")
	end

	# Go through one of the three hashes to extract the desired information and write it to the file.

		$name_to_node.each do |key, node|
			src = $hostname
			dst = key
			nextHop = node.nextHop
			distance = node.distance

			s = [src, dst, nextHop, distance.to_s].join(",")
			f.puts(s)
		end
	f.close
end

# Method to cleanly shutdown a node.
def shutdown()
	# Close every socket connected to the node.
		$socket_to_node.keys.each { |s| s.close}

	# Flush all pending write buffers (stdout, stderr).
	$stdout.flush
	$stderr.flush

	# Kill every thread.
	Thread.kill(@listeningThread)
	Thread.kill(@readWriteThread)
	Thread.kill(@timeThread)

	exit 0
end


# --------------------- Part 1 --------------------- # 
def edged(args)
	dest = args[0]

	node = $name_to_node[dest]
	node.socket.close	# Close the socket before deleting the object.

	$name_to_node.delete(dest)
end

def edgeu(args)
	dest = args[0]
	cost = args[1]

	node = $name_to_node[dest]

	if (node.isNeighbor)
		node.linkCost = cost
	end
end

def getNeighbors()
	return $name_to_node.keys.sort
end

def status()
	name = $hostname
	port = $port
	neighbors = getNeighbors().join(',')

	STDOUT.puts("Name: #{name} Port: #{port} Neighbors: #{neighbors}")
end

# --------------------- Part 2 --------------------- # 
def sendmsg(args)
	STDOUT.puts "SENDMSG: not implemented"
end

def ping(args)
	STDOUT.puts "PING: not implemented"
end

def traceroute(args)
	STDOUT.puts "TRACEROUTE: not implemented"
end

def ftp(args)
	STDOUT.puts "FTP: not implemented"
end

# --------------------- Part 3 --------------------- # 
def circuit(args)
	STDOUT.puts "CIRCUIT: not implemented"
end

def handleThread()
	while(line = STDIN.gets)
		line = line.strip
		arr = line.split(' ')
		cmd = arr[0]
		args = arr[1..-1]
		case cmd
		when "EDGEB"; edgeb(args)
		when "EDGED"; edged(args)
		when "EDGEU"; edgeu(args)
		when "DUMPTABLE"; dumptable(args)
		when "SHUTDOWN"; shutdown
		when "STATUS"; status
		when "SENDMSG"; sendmsg(args)
		when "PING"; ping(args)
		when "TRACEROUTE"; traceroute(args)
		when "FTP"; ftp(args)
		when "CIRCUIT"; circuit(args)
		else STDERR.puts "ERROR: INVALID COMMAND \"#{cmd}\""
		end
	end
end

def handleNetwork(recvBuffer, socket)
	arr = recvBuffer.chomp().split(',')
	cmd = arr[0]
	args = arr[1..-1]

	case cmd
		when "EDGEB"; edgeb_network(args, socket)
		when "SENDMSG"; sendmsg(args)
		when "PING"; ping(args)
		when "TRACEROUTE"; traceroute(args)
		when "FTP"; ftp(args)
		when "CIRCUIT"; circuit(args)
		when "FLOODING"; flooding(args)
		else STDERR.puts "ERROR: INVALID COMMAND \"#{cmd}\""
	end
	return
end

def readWriteThread
	# Use this thread for flooding and dijkstra's algorithm.
	# For flooding:
	# - Having internal clock.
	# - When updateInterval have passed it's okay for the thread to flood.
	# - Flooding on the precise time of updateInterval is not necessary.

	timeout = 0.25

	loop {

		$nodeLock.synchronize {

			# Create link state packet for the node itself.
			packet = createLinkStatePacket
			# Pass packet to own flooding method to start constructing the graph and to flood to neighbors.
			handleNetwork(packet, nil)

			rTemp = $socket_to_node.keys

			r,w,e = IO.select(rTemp, nil, nil, timeout)

			if $time - $timeLastUpdate >= $updateInterval
				$timeLastUpdate = $time
				flooding(packet)
			end

			# Check if the array is empty.
			if(r == nil)
				next
			end

			r.each { |readable_socket|
				$socket_to_node[readable_socket].recvBuffer << readable_socket.gets()
				STDOUT.puts $socket_to_node[readable_socket].recvBuffer
			}

			r.each { |readable_socket|
				buffer = $socket_to_node[readable_socket].recvBuffer
				handleNetwork(buffer, readable_socket)
			}

			$socket_to_node.values.each {|n|
				while n.sendBuffer.length > 0 # check if
					writtenBytes = n.socket.puts(n.sendBuffer)
					n.sendBuffer.shift(writtenBytes)
				end
			}
		}
	}
end

def listeningThread
	server = TCPServer.new($port)

	loop {
		client = server.accept()
		node = NodeClass.new
		node.socket = client
		$nodeLock.synchronize {
			$socket_to_node[client] = node # add node to hash
		}
	}
end

def timeThread
	timeUpdateInterval = 0.1

	loop {
		sleep(timeUpdateInterval)
		$time += timeUpdateInterval
	}
end

# Method to parse the information given in nodes.txt to an global Hash.
def parseNodes(nodes)
  fHandle = File.open(nodes)
  while(line = fHandle.gets)
    arr = line.chomp.split(',')

    node_name = arr[0]
    node_port = Integer(arr[1])

    $nodes[node_name] = node_port
  end
end

# Method to parse the information given in config to an global Hash.
def parseConfig(config)
	fHandle = File.open(config)
	while(line = fHandle.gets)
		arr = line.chomp.split('=')

		option = arr[0]
		value = Integer(arr[1])

		$config[option] = value
	end
end

def setup(hostname, port, nodes, config) #Example: n1 10241 nodes config

	$time = Time.new

	$hostname = hostname
	$port = Integer(port) # Parse the string port to an integer.

	# Hashes to store information from the nodes.txt and config file.
	$nodes = Hash.new
	$config = Hash.new

	# The header length needs to be variable and not static.
	#$headerLength = 100

	# Parse information in given files to internal data structures.
	parseNodes(nodes)
	parseConfig(config)

	# Three hashes that allows to get access to the same node object in three different ways.
	$socket_to_node = Hash.new
	$ip_to_node = Hash.new
	$name_to_node = Hash.new

	$updateInterval = $config["updateInterval"]

	# Sequence variable used for the link state packets.
	$sequenceNumber = 1
	# Hash to keep track for link packets received from other nodes.
	$src_to_seq = Hash.new
	# Hash to store link state packets.
	$edges = Hash.new

	# ListeningThread is used for listening for incoming connections from other nodes in the network.
	# ReadWriteThread is used for reading what is available on readable sockets and to write what's stored in write buffers.
	# HandleThread is used for handling instructions from STDin (Terminal).
	@listeningThread = Thread.new{listeningThread}
	@readWriteThread = Thread.new{readWriteThread}
	@handleThread = Thread.new{handleThread}
	$time = Time.now
	$timeLastUpdate = $time
	@timeThread = Thread.new{timeThread}

	@listeningThread.join
	@readWriteThread.join
	@handleThread.join

end

setup(ARGV[0], ARGV[1], ARGV[2], ARGV[3])